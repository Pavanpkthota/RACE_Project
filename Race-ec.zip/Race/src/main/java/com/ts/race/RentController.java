package com.ts.race;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ts.dao.CarDao;
import com.ts.dao.RentDao;
import com.ts.model.Car;
import com.ts.model.Customer;
import com.ts.model.Rent;

@RestController
public class RentController {

	
	@Autowired
	RentDao rentDao;
	
	
	@PostMapping("/bookCar")			
	public void bookCar(@RequestBody Rent rent){
		
		System.out.println("Rent Data Received From Angular");
		System.out.println(rent);	
		rentDao.book(rent);
	}
	
	
	@RequestMapping("/currentrentedcar/{emailId}")
	public List<Rent> currentRentedCar(@PathVariable("emailId") String emailId){
		List<Rent> rent = rentDao.currentRentedCar(emailId);
		return rent;		
	}
	
	@PostMapping("/cancel")
	public void cancel(@RequestBody Rent rent){
		rentDao.cancel(rent);
	
	}
	
	@RequestMapping("/customerbookedcar/{emailId}")
	public List<Rent> getCustomerBookedCar(@PathVariable("emailId") String emailId){
		List<Rent> rent = rentDao.getCustomerBookedCar(emailId);
		return rent;		
	}
	
	
}
