package com.ts.race;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ts.dao.CarDao;
import com.ts.model.Car;
import com.ts.model.Customer;
import com.ts.model.Rent;

@RestController
public class CarController {

	@Autowired
	CarDao carDao;
	
	
	@PostMapping("/addCar")			
	public void addCarDetails(@RequestBody Car car){
		
		System.out.println("Car Data Received From Angular");
		System.out.println(car);	
		carDao.add(car);
	}
	
	@RequestMapping("/getCars/{searchForm}")
	public List<Car> getCarsByLocation(@PathVariable("searchForm") String searchForm){
		List<Car> car = carDao.getCars(searchForm);
		return car;		
	}
	
	
	@RequestMapping("/ownerCars/{emailId}")
	public List<Car> getCarsByOwnerEmailId(@PathVariable("emailId") String emailId){
		List<Car> car = carDao.getOwnerCars(emailId);
		return car;		
	}
	
	
	@PostMapping("/remove")
	public void cancel(@RequestBody Car car){
		System.out.println("remove car request Received From Angular");
		System.out.println(car);
		carDao.removeCar(car);
	
	}
	
}
