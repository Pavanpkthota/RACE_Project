package com.ts.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ts.model.Car;
import com.ts.model.Customer;
import com.ts.model.Rent;

public interface RentRepository extends JpaRepository<Rent,Integer>{

	
	List<Rent> findByCustomerEmailId(String CustomerEmailId);
	
	void delete(Rent rent);
	
	
	List<Rent> findByOwnerEmailId(String OwnerEmailId);
}
