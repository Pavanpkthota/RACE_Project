package com.ts.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ts.model.Car;
import com.ts.model.Customer;
import com.ts.model.Rent;

@Service
public class CarDao {

	
	@Autowired
	CarRepository carRepository;	
	
	
	public void add(Car car) {
		carRepository.save(car);
	}	
	
	public List<Car> getCars(String location) {
		List<Car> car = carRepository.findByAvailableLocation(location);
		return car;
	}
	
	
	public List<Car> getOwnerCars(String emailId) {
		List<Car> car = carRepository.findByOwnerEmailId(emailId);
		return car;
	}
	
	public void removeCar(Car car) {
		System.out.println("remove car request is in dao");
		 carRepository.delete(car);
			
	}
}
