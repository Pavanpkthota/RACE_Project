package com.ts.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ts.model.Car;
import com.ts.model.Customer;
import com.ts.model.Rent;
@Service
public class RentDao {



	@Autowired
	RentRepository rentRepository;	
	
	
	public void book(Rent rent) {
		rentRepository.save(rent);
	}
	
	public List<Rent> currentRentedCar(String emailId) {
		List<Rent> rent = rentRepository.findByCustomerEmailId(emailId);
		return rent;
	}
	
	public void cancel(Rent rent) {
		 rentRepository.delete(rent);
			
	}
	
	public List<Rent> getCustomerBookedCar(String emailId) {
		List<Rent> rent = rentRepository.findByOwnerEmailId(emailId);
		return rent;
	}
}
